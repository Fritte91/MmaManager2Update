import Image from "next/image"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

// Coach data for the table
const coachesData = [
  { name: "Coach Mike", specialty: "Boxing", cost: "$5,000", bonus: "+15% Punch Power" },
  { name: "Coach Sarah", specialty: "Kickboxing", cost: "$5,500", bonus: "+15% Kick Power" },
  { name: "Coach Ivan", specialty: "Wrestling", cost: "$6,000", bonus: "+15% Takedown" },
  { name: "Coach Hiroshi", specialty: "Jiu-Jitsu", cost: "$6,500", bonus: "+15% Submission" },
  { name: "Coach Dmitri", specialty: "Sambo", cost: "$7,000", bonus: "+10% All Stats" },
]

// Equipment data
const equipmentData = [
  {
    name: "Treadmill",
    image: "/placeholder.svg?height=200&width=200",
    description: "Improves fighters' conditioning.",
  },
  {
    name: "Bench Press",
    image: "/placeholder.svg?height=200&width=200",
    description: "Builds strength.",
  },
  {
    name: "Stepper",
    image: "/placeholder.svg?height=200&width=200",
    description: "Enhances agility.",
  },
  {
    name: "Bike",
    image: "/placeholder.svg?height=200&width=200",
    description: "Boosts conditioning.",
  },
  {
    name: "Dumbbells",
    image: "/placeholder.svg?height=200&width=200",
    description: "Focuses on strength training.",
  },
  {
    name: "Speed Bag",
    image: "/placeholder.svg?height=200&width=200",
    description: "Improves agility.",
  },
  {
    name: "Knee Bag",
    image: "/placeholder.svg?height=200&width=200",
    description: "Enhances power and technique for knees.",
  },
  {
    name: "Standing Dummy",
    image: "/placeholder.svg?height=200&width=200",
    description: "Practicing clinchwork and strikes.",
  },
  {
    name: "Punching Bag",
    image: "/placeholder.svg?height=200&width=200",
    description: "Develops punching power and technique.",
  },
  {
    name: "Kick Bag",
    image: "/placeholder.svg?height=200&width=200",
    description: "Improves kick strength and accuracy.",
  },
  {
    name: "Grappling Dummy",
    image: "/placeholder.svg?height=200&width=200",
    description: "Enhances grappling and submissions.",
  },
  {
    name: "Boxing Ring",
    image: "/placeholder.svg?height=200&width=200",
    description: "Train defense, clinchwork, and positioning.",
  },
]

export default function GymEquipment() {
  return (
    <div className="container py-12 md:py-16 lg:py-24">
      <header className="text-center mb-12">
        <h1 className="text-4xl font-bold tracking-tight mb-4">Gym Equipment</h1>
        <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
          Upgrade your gym with the right equipment to maximize your fighters' potential
        </p>
      </header>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {equipmentData.map((item, index) => (
          <Card key={index} className="card-hover overflow-hidden">
            <div className="aspect-square relative">
              <Image
                src={item.image || "/placeholder.svg"}
                alt={item.name}
                fill
                className="object-cover transition-transform hover:scale-105"
              />
            </div>
            <CardHeader className="p-4">
              <CardTitle className="text-lg">{item.name}</CardTitle>
            </CardHeader>
            <CardContent className="p-4 pt-0">
              <p className="text-sm text-muted-foreground">{item.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="mt-16">
        <h2 className="text-3xl font-bold tracking-tight mb-8 text-center">Fight Coaches</h2>
        <Card>
          <CardContent className="p-6">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Specialty</TableHead>
                  <TableHead>Cost</TableHead>
                  <TableHead>Bonus</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {coachesData.map((coach, index) => (
                  <TableRow key={index}>
                    <TableCell className="font-medium">{coach.name}</TableCell>
                    <TableCell>{coach.specialty}</TableCell>
                    <TableCell>{coach.cost}</TableCell>
                    <TableCell>{coach.bonus}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
