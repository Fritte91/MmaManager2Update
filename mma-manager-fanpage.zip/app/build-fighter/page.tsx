"use client"

import { useState } from "react"
import Image from "next/image"
import { Card } from "@/components/ui/card"
import { Slider } from "@/components/ui/slider"
import { Button } from "@/components/ui/button"

const skills = [
  "Punches",
  "Elbows",
  "Knees",
  "High Kicks",
  "Low Kicks",
  "Clinchwork",
  "Takedowns",
  "Ground Grappling",
  "Submission",
  "Strike Def",
  "Knees Def",
  "Kick Def",
  "Takedown Def",
  "Submission Def",
]

const maxTotalPoints = 19000
const maxSkillPoints = 3400

export default function BuildFighter() {
  const [skillPoints, setSkillPoints] = useState(
    skills.reduce((acc, skill) => {
      acc[skill] = 0
      return acc
    }, {}),
  )

  const [coreStats, setCoreStats] = useState({
    Strength: 50,
    Agility: 50,
    Conditioning: 50,
  })

  const totalPoints = Object.values(skillPoints).reduce((a, b) => a + b, 0)

  const handleSkillChange = (skill, value) => {
    const newValue = Number.parseInt(value)
    const oldValue = skillPoints[skill]
    const change = newValue - oldValue

    const newTotalPoints = totalPoints + change

    if (newTotalPoints <= maxTotalPoints && newValue <= maxSkillPoints && newValue >= 0) {
      setSkillPoints((prevState) => ({
        ...prevState,
        [skill]: newValue,
      }))
    }
  }

  const handleCoreStatChange = (stat, value) => {
    setCoreStats((prevState) => ({
      ...prevState,
      [stat]: value[0],
    }))
  }

  const calculateFighterLevel = () => {
    return Math.floor(totalPoints / 1583.33)
  }

  const resetSkills = () => {
    setSkillPoints(
      skills.reduce((acc, skill) => {
        acc[skill] = 0
        return acc
      }, {}),
    )
  }

  return (
    <div className="container py-12 md:py-16 lg:py-24">
      <header className="text-center mb-12">
        <h1 className="text-4xl font-bold tracking-tight mb-4">Fighter Builder</h1>
        <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
          Create and customize your fighter's skills and attributes
        </p>
      </header>

      <div className="grid gap-8 lg:grid-cols-[1fr_2fr]">
        {/* Left side: Fighter image + level + attributes */}
        <div>
          <Card className="p-6">
            <div className="flex flex-col items-center">
              <div className="relative w-64 h-64 mb-4">
                <Image
                  src="/placeholder.svg?height=256&width=256"
                  alt="Fighter Model"
                  fill
                  className="object-cover rounded-md"
                />
              </div>
              <div className="text-2xl font-bold mb-6">Level {calculateFighterLevel()}</div>

              <div className="w-full space-y-6">
                <h3 className="text-xl font-bold mb-4">Core Stats</h3>
                {Object.entries(coreStats).map(([stat, value]) => (
                  <div key={stat} className="space-y-2">
                    <div className="flex justify-between">
                      <label className="font-medium">{stat}</label>
                      <span>{value}%</span>
                    </div>
                    <Slider
                      value={[value]}
                      min={0}
                      max={100}
                      step={1}
                      onValueChange={(value) => handleCoreStatChange(stat, value)}
                    />
                  </div>
                ))}
              </div>
            </div>
          </Card>
        </div>

        {/* Right side: Skills */}
        <Card className="p-6">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-xl font-bold">Fighter Skills</h3>
            <div className="text-sm font-medium">
              Total Points: {totalPoints} / {maxTotalPoints}
            </div>
          </div>

          <div className="space-y-6">
            {skills.map((skill) => (
              <div key={skill} className="space-y-2">
                <div className="flex justify-between">
                  <label className="font-medium">{skill}</label>
                  <span>{skillPoints[skill]}</span>
                </div>
                <Slider
                  value={[skillPoints[skill]]}
                  min={0}
                  max={maxSkillPoints}
                  step={10}
                  onValueChange={(value) => handleSkillChange(skill, value[0])}
                />
              </div>
            ))}
          </div>

          <div className="mt-8 flex justify-end">
            <Button variant="destructive" onClick={resetSkills}>
              Reset Skills
            </Button>
          </div>
        </Card>
      </div>
    </div>
  )
}
