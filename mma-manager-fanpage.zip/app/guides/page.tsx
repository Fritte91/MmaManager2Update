"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ChevronDown, ChevronUp } from "lucide-react"

const Guide = ({ title, content }) => {
  const [isActive, setIsActive] = useState(false)

  const toggleContent = () => {
    setIsActive(!isActive)
  }

  return (
    <Card className={`mb-4 transition-all ${isActive ? "ring-2 ring-primary" : ""}`}>
      <CardHeader className="cursor-pointer flex flex-row items-center justify-between p-4" onClick={toggleContent}>
        <CardTitle className="text-xl">{title}</CardTitle>
        {isActive ? <ChevronUp className="h-5 w-5" /> : <ChevronDown className="h-5 w-5" />}
      </CardHeader>
      {isActive && (
        <CardContent className="pt-0 px-4 pb-4">
          <div dangerouslySetInnerHTML={{ __html: content }} />
        </CardContent>
      )}
    </Card>
  )
}

export default function Guides() {
  return (
    <div className="container py-12 md:py-16 lg:py-24">
      <header className="text-center mb-12">
        <h1 className="text-4xl font-bold tracking-tight mb-4">Guides in MMA Manager 2</h1>
        <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
          Explore various guides to enhance your gameplay
        </p>
      </header>

      <div className="max-w-4xl mx-auto">
        <Guide
          title="Unlock Fighting Moves"
          content="<div class='space-y-4'>
                    <div>
                      <h3 class='font-bold text-lg mb-2'>Punch</h3>
                      <ul class='space-y-1'>
                        <li>60    → Hook</li>
                        <li>150   → Cross</li>
                        <li>220   → Clinch hook</li>
                        <li>420   → Side mount retaliate punch</li>
                        <li>700   → Full guard back punch</li>
                        <li>860   → Uppercut</li>
                        <li>1220 → Overhand punch</li>
                        <li>1430 → Clinch uppercut</li>
                        <li>1880 → Top mount retaliate punch</li>
                        <li>2120 → Power punch</li>
                        <li>2380 → Superman punch</li>
                      </ul>
                    </div>
                    <div>
                      <h3 class='font-bold text-lg mb-2'>Elbow</h3>
                      <ul class='space-y-1'>
                        <li>1450 → Muaythai clinch elbow</li>
                      </ul>
                    </div>
                    <div>
                      <h3 class='font-bold text-lg mb-2'>Knee</h3>
                      <ul class='space-y-1'>
                        <li>450 → Muaythai clinch knee</li>
                        <li>950 → Aggressive knee</li>
                      </ul>
                    </div>
                    <div>
                      <h3 class='font-bold text-lg mb-2'>Low kick</h3>
                      <ul class='space-y-1'>
                        <li>150   → Front kick</li>
                        <li>300  → Push kick</li>
                        <li>600  → Taekwondo defensive low kick</li>
                        <li>1100 → Muaythai leg kick</li>
                        <li>1700 → Taekwondo side kick</li>
                      </ul>
                    </div>
                    <div>
                      <h3 class='font-bold text-lg mb-2'>High kick</h3>
                      <ul class='space-y-1'>
                        <li>150   → High kick</li>
                        <li>300  → Roundhouse kick</li>
                        <li>600  → Capoeira spinning mid kick</li>
                        <li>1100 → Muaythai axe kick</li>
                        <li>1700 → Taekwondo bolley high kick</li>
                      </ul>
                    </div>
                    <div>
                      <h3 class='font-bold text-lg mb-2'>Takedown</h3>
                      <ul class='space-y-1'>
                        <li>200  → Throw</li>
                        <li>500   → Single-leg takedown</li>
                        <li>1200  → Whizzer throw</li>
                      </ul>
                    </div>
                    <div>
                      <h3 class='font-bold text-lg mb-2'>Submission</h3>
                      <ul class='space-y-1'>
                        <li>500 → Kimura</li>
                      </ul>
                    </div>
                    <div>
                      <h3 class='font-bold text-lg mb-2'>Ground Grappling</h3>
                      <ul class='space-y-1'>
                        <li>1000 → Ground sweep reverse</li>
                        <li>1500 → Great reversal</li>
                      </ul>
                    </div>
                    <p class='text-sm text-muted-foreground'>Credit To @Wann</p>
                  </div>"
        />
        <Guide
          title="Just Getting Started Guide"
          content="<ol class='list-decimal pl-5 space-y-4'>
                    <li>When you first get started, be very careful not to waste any resources, mainly credits and Focus. They are incredibly valuable in the long run and won't come as easily as when you're first starting.</li>
                    <li>Credits can be used to upgrade rings and base stat equipment (+ unlocking talents later). A good rule of thumb is to at least upgrade one ring, one speed bag (Agility), one training bike (Conditioning), and one dumbbell (strength) to the fullest. The shorter training times are such a lifesaver, especially when your fighter gets higher and higher in level, you won't have to wait for 3-5 mins on every training.</li>
                    <li>Mental points need to be saved as much as possible and only invested in your main fighter (at the beginning). There are basically tiers when it comes to the boosts available: Tier 1 (Best): Initiative + Health Tier 2 (Great): Block Chance + Hit Chance. Other boosts come lower, with health regeneration being the least important of them. So when building your main fighter, it's definitely worth it to invest mental points in agility and health first, then you can choose from the rest depending on your build's needs.</li>
                    <li>Don't put all of your eggs in one basket (don't hyper-fixate on upgrading one type of equipment, try to boost your gym gradually).</li>
                    <li>Try to give each fighter a unique build, fighters are divided into these categories:
                        <ul class='list-disc pl-5 mt-2 space-y-2'>
                            <li>A) Ground fighters:
                                <ul class='list-disc pl-5 mt-1'>
                                    <li>Wrestlers</li>
                                    <li>Submission Artists</li>
                                </ul>
                            </li>
                            <li>B) Strikers:
                                <ul class='list-disc pl-5 mt-1'>
                                    <li>Boxers</li>
                                    <li>Kickboxers (High kick + punch or Low Kick + Punch)</li>
                                    <li>Kickers (either low kick or high kick)</li>
                                </ul>
                            </li>
                            <li>C) Clinchers:
                                <ul class='list-disc pl-5 mt-1'>
                                    <li>Punch clinch</li>
                                    <li>Elbow clinch</li>
                                    <li>Knee clinch</li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li>What to look for in a discipline card?
                        <ul class='list-disc pl-5 mt-2'>
                            <li>Agility (fight winner hands down)</li>
                            <li>Conditioning (better than health boosts since the former also helps with takedown def, clinch def, sub def, and gg)</li>
                            <li>Hit Chance</li>
                            <li>Combo chance</li>
                            <li>Critical chance</li>
                            <li>Critical damage</li>
                        </ul>
                    </li>
                    <li>Don't spread your points too soon: a lot of people know what their overall build should look like, but they start adding points left and right instead of concentrating them on the main skills of the build.</li>
                    <li>For example, a wrestler at level 12 should have points in gg, takedowns, clinch, sub def, strike def, kick def, and punch/elbows. If you try to spread your points at level 6 for all these categories, you'll be left with an average fighter that gets smashed left and right. It's better to put most of the points in gg and takedowns in the beginning, then slowly and gradually fill out the other skills.</li>
                    <li>Try to get your fighters as high in the pro league as you can. The pro league grants you a lot of valuable rewards, especially the credits as they seriously add up with time (and GC tickets as well). So get your fighters as far in the pro league as you can.</li>
                    <li>You can train your fighters to lvl 5 easily without needing to wait for stamina, so it's a good starting point to see how you fair in tournaments and pro league.</li>
                </ol>
                <p class='text-sm text-muted-foreground mt-4'>Credit To @Slim</p>"
        />
        <Guide
          title="Farming Cash & Prestige"
          content="<div class='space-y-4'>
                    <h3 class='font-bold text-lg'>FARMING CASH AND PRESTIGE</h3>
                    <p>The easiest way to farm Cash and prestige is to finish the campaign and watch ads after you beat your opponent in each stage. Maybe a little boring. But believe me, this will really help us to get Cash and prestige quickly.</p>
                    
                    <h3 class='font-bold text-lg'>Farming scrolls</h3>
                    <p>There are 2 ways to get scrolls for free:</p>
                    <ol class='list-decimal pl-5 space-y-2'>
                        <li><strong>Daily Quest:</strong> Every day you will get 2 scrolls from the daily quest.</li>
                        <li><strong>Fight Club:</strong> The number of scrolls you get varies depending on the level of the fighter registered. If you win, you will get:
                            <ul class='list-disc pl-5 mt-1'>
                                <li>Lv3 - Lv5 = 1 scroll</li>
                                <li>Lv6 - Lv9 = 2 scrolls</li>
                                <li>Lv10 - Lv12 = 3 scrolls</li>
                            </ul>
                        </li>
                    </ol>
                    <p>And not just get the scrolls. You will get Cash and common talent coins (which work to unlock common talents). I suggest using your fighter with full skills and Base points at each level (to have a higher chance to win the fight club).</p>
                    <p class='text-sm text-muted-foreground'>Credit To @Wann</p>
                  </div>"
        />
        <Guide
          title="Tournament"
          content="<div class='space-y-4'>
                    <ul class='space-y-2'>
                      <li><strong>☆ Each player gets 2 tickets every week (Monday at 00:00 UTC+0)</strong></li>
                      <li>☆ The registration time lasts for 24 hours since registration is open.</li>
                      <li>☆ Lv5 is the minimum fighter's level to register for a tournament.</li>
                      <li>☆ In 1 tournament bracket, there are 32 fighters.</li>
                      <li>☆ Fighters registered in the tournament cannot be trained. But your fighter will get bonus skill points when they go home.</li>
                      <li><strong>☆ Tournament rewards that are unclaimed at the end of the week get discarded.</strong></li>
                    </ul>
                    
                    <p><strong>NOTE:</strong></p>
                    <p>☆ It is very important to increase your Base skill (strength, condition, agility). Every time you increase your level, you must immediately max your Base skill. Otherwise, your fighter will be difficult to win the fight.</p>
                    <p class='text-sm text-muted-foreground'>Credit To @Wann</p>
                  </div>"
        />
        <Guide
          title="Different Builds"
          content="<div class='space-y-6'>
                    <p>You can always come up with your own build; those are for learning purposes and from a player's point of view.</p>
                
                    <div>
                      <h3 class='font-bold text-lg mb-2'>1) Clinchers:</h3>
                      <div class='pl-4'>
                        <p><strong>☆ Strong points:</strong></p>
                        <ul class='list-disc pl-5 space-y-1'>
                            <li>Supported by the majority of the talents</li>
                            <li>Supported by a large number of disciplines</li>
                            <li>Can use lower strike and kick defense due to time spent in the clinch.</li>
                        </ul>
                        <p class='mt-2'><strong>☆ Weak points:</strong></p>
                        <ul class='list-disc pl-5 space-y-1'>
                            <li>More vulnerable to takedowns than strikers as the clinch facilitates takedowns.</li>
                        </ul>
                      </div>
                    </div>
                
                    <div>
                      <h3 class='font-bold text-lg mb-2'>2) Wrestlers:</h3>
                      <div class='pl-4'>
                        <p><strong>☆ Strong points:</strong></p>
                        <ul class='list-disc pl-5 space-y-1'>
                            <li>Can use lower strike and kick defense due to time spent on the ground</li>
                            <li>Can use little to no attack points (only the ground matters)</li>
                            <li>Most people have their default gameplans set to offensive or off all-in, which weakens takedown defense and allows you to take advantage further (whether in fight club or pro league)</li>
                        </ul>
                        <p class='mt-2'><strong>☆ Weak points:</strong></p>
                        <ul class='list-disc pl-5 space-y-1'>
                            <li>Can only seriously hurt opponents on the ground, so if the takedown doesn't come, you're done.</li>
                            <li>Major problems with taking down clinchers, especially when in the clinch. The huge amount of takedown defense boosters makes it really hard for wrestlers in the endgame.</li>
                        </ul>
                      </div>
                    </div>
                
                    <div>
                      <h3 class='font-bold text-lg mb-2'>3) Boxers:</h3>
                      <div class='pl-4'>
                        <p><strong>☆ Strong points:</strong></p>
                        <ul class='list-disc pl-5 space-y-1'>
                            <li>The punch is the easiest strike to land (70-80% precision) and directly benefits from agility/initiative boosts</li>
                            <li>Supported well by a lot of discipline cards and talents</li>
                            <li>Benefits from every striking boost, whether it's combo chance, critical chance, critical damage, or hit chance.</li>
                            <li>Can land from any position (Standing, ground, clinch)</li>
                            <li>Leaves plenty of points to defenses and consequently doesn't have any major anti-build.</li>
                        </ul>
                        <p class='mt-2'><strong>☆ Weak points:</strong></p>
                        <ul class='list-disc pl-5 space-y-1'>
                            <li>One dimensional</li>
                        </ul>
                      </div>
                    </div>
                
                    <div>
                      <h3 class='font-bold text-lg mb-2'>4) Kickers:</h3>
                      <div class='pl-4'>
                        <p><strong>☆ Strong points:</strong></p>
                        <ul class='list-disc pl-5 space-y-1'>
                            <li>Very high critical damage, can one-shot / two-shot opponents or get a KO at any time</li>
                            <li>Can be content with sitting back and defending / eating shots then unloading a +200 damage attack.</li>
                        </ul>
                        <p class='mt-2'><strong>☆ Weak points:</strong></p>
                        <ul class='list-disc pl-5 space-y-1'>
                            <li>High loss of initiative after missing</li>
                            <li>Harder to land than punches</li>
                            <li>Susceptible to both takedowns and the clinch</li>
                        </ul>
                      </div>
                    </div>
                
                    <div>
                      <h3 class='font-bold text-lg mb-2'>5) Kickboxers:</h3>
                      <div class='pl-4'>
                        <p><strong>☆ Strong points:</strong></p>
                        <ul class='list-disc pl-5 space-y-1'>
                            <li>Combines both boxer and kicker perks, works really well with critical boosts</li>
                            <li>Ability to crack opponents by varied attacks</li>
                            <li>Unpredictability as you can turn them into a kicker or a boxer for any fight</li>
                        </ul>
                        <p class='mt-2'><strong>☆ Weak points:</strong></p>
                        <ul class='list-disc pl-5 space-y-1'>
                            <li>Endgame build will have a deficit in strike and kick defense</li>
                            <li>Most fights at level 12 end by decision, so the decreased defense could backfire if you don't get a KO.</li>
                        </ul>
                      </div>
                    </div>
                
                    <p>There are 10 disciplines in this game. Each discipline has a different passive. Use discipline with a passive that is useful for your fighter. You can unlock disciplines by reaching Chapter 20 in the Manager Journey.</p>
                    
                    <div>
                      <p><strong>Example:</strong></p>
                      <ul class='list-disc pl-5 space-y-1'>
                          <li>a. Boxing (punch) = boxing, kravmaga, karate, sambo</li>
                          <li>b. Taekwondo (high kick) = taekwondo (Required), karate, kravmaga, sambo</li>
                          <li>c. Kickboxing (low kick) = kickboxing, sambo, karate, kravmaga</li>
                          <li>d. Muaythai (clinch) = muaythai, karate, kravmaga, sambo</li>
                          <li>e. BJJ = bjj, wrestling, judo</li>
                          <li>f. Ground N pound = wrestling, judo, boxing (if you use punch attack), sambo</li>
                      </ul>
                    </div>
                    
                    <p>Each fighter can use 2 discipline cards. So choose the right one...</p>
                    
                    <p>The discipline effect is only activated when the discipline card reaches level 3. Then each successive level increases the effect.</p>
                    
                    <p>Higher stats for legendary cards.</p>
                    <p class='text-sm text-muted-foreground'>Credit To @Slim</p>
                  </div>"
        />
      </div>
    </div>
  )
}
