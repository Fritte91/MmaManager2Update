import { Dumbbell, Award, BookOpen, Users, Zap, BarChart, Target } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function GettingStarted() {
  return (
    <div className="container py-12 md:py-16 lg:py-24">
      <header className="text-center mb-12">
        <h1 className="text-4xl font-bold tracking-tight mb-4">Getting Started with MMA Manager 2</h1>
        <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
          Your guide to understanding the game mechanics and strategies for success.
        </p>
      </header>

      <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
        <Card className="card-hover">
          <CardHeader>
            <div className="flex items-center gap-2 mb-2">
              <Zap className="h-6 w-6 text-primary" />
              <CardTitle>Game Currencies</CardTitle>
            </div>
            <CardDescription>
              Understanding the game's currencies is crucial for managing your resources effectively
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              <li className="flex items-start gap-2">
                <span className="font-semibold">Cash:</span>
                <span className="text-muted-foreground">For upgrading gyms and purchasing equipment.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="font-semibold">Credits:</span>
                <span className="text-muted-foreground">A premium currency for achievements or purchases.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="font-semibold">Focus Points:</span>
                <span className="text-muted-foreground">Vital for fighter training.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="font-semibold">Prestige:</span>
                <span className="text-muted-foreground">Earned through game progression.</span>
              </li>
            </ul>
          </CardContent>
        </Card>

        <Card className="card-hover">
          <CardHeader>
            <div className="flex items-center gap-2 mb-2">
              <BarChart className="h-6 w-6 text-primary" />
              <CardTitle>Fighter Stats</CardTitle>
            </div>
            <CardDescription>Core attributes that define your fighter's performance</CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              <li className="flex items-start gap-2">
                <span className="font-semibold">Strength:</span>
                <span className="text-muted-foreground">Increases damage output on strikes.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="font-semibold">Agility:</span>
                <span className="text-muted-foreground">Influences initiative and attacks per fight.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="font-semibold">Condition:</span>
                <span className="text-muted-foreground">Affects health, regeneration, and defense.</span>
              </li>
            </ul>
          </CardContent>
        </Card>

        <Card className="card-hover">
          <CardHeader>
            <div className="flex items-center gap-2 mb-2">
              <Award className="h-6 w-6 text-primary" />
              <CardTitle>Disciplines and Talents</CardTitle>
            </div>
            <CardDescription>Key to fighter development</CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              <li className="flex items-start gap-2">
                <span className="font-semibold">Disciplines:</span>
                <span className="text-muted-foreground">Fighting styles like Boxing, Muay Thai, or Wrestling.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="font-semibold">Talents:</span>
                <span className="text-muted-foreground">Passive abilities enhancing fighter stats.</span>
              </li>
            </ul>
          </CardContent>
        </Card>

        <Card className="card-hover">
          <CardHeader>
            <div className="flex items-center gap-2 mb-2">
              <Dumbbell className="h-6 w-6 text-primary" />
              <CardTitle>Gym Management</CardTitle>
            </div>
            <CardDescription>Your gym is the backbone of your success</CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              <li className="text-muted-foreground">
                Upgrade gym facilities to increase the quality of training sessions, and gain more prestige the higher
                level each equipment is.
              </li>
              <li className="text-muted-foreground">
                Equip your gym with specialized equipment that boosts specific stats for fighters.
              </li>
              <li className="text-muted-foreground">
                Manage resources to train multiple fighters without overextending your focus points.
              </li>
            </ul>
          </CardContent>
        </Card>

        <Card className="card-hover">
          <CardHeader>
            <div className="flex items-center gap-2 mb-2">
              <Target className="h-6 w-6 text-primary" />
              <CardTitle>Progression Strategy</CardTitle>
            </div>
            <CardDescription>Develop a strategy for progressing through the game</CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              <li className="flex items-start gap-2">
                <span className="font-semibold">Early Game:</span>
                <span className="text-muted-foreground">
                  Focus on recruiting a balanced team of fighters and improving their core stats.
                </span>
              </li>
              <li className="flex items-start gap-2">
                <span className="font-semibold">Mid-Game:</span>
                <span className="text-muted-foreground">
                  Upgrade your gym and experiment with different disciplines and talents.
                </span>
              </li>
              <li className="flex items-start gap-2">
                <span className="font-semibold">Late Game:</span>
                <span className="text-muted-foreground">Compete in higher leagues and focus on prestige rewards.</span>
              </li>
            </ul>
          </CardContent>
        </Card>

        <Card className="card-hover">
          <CardHeader>
            <div className="flex items-center gap-2 mb-2">
              <BookOpen className="h-6 w-6 text-primary" />
              <CardTitle>Combat Preparation</CardTitle>
            </div>
            <CardDescription>Before every fight</CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              <li className="text-muted-foreground">Review your opponent's stats and fighting style.</li>
              <li className="text-muted-foreground">
                Adjust your fighter's tactics, focusing on strengths that exploit the opponent's weaknesses.
              </li>
              <li className="text-muted-foreground">
                Train fighters adequately to ensure peak performance during matches.
              </li>
              <li className="text-muted-foreground">Choose if you go Aggressive, defensive or normal.</li>
            </ul>
          </CardContent>
        </Card>
      </div>

      <div className="mt-12">
        <Card className="card-hover">
          <CardHeader>
            <div className="flex items-center gap-2 mb-2">
              <Users className="h-6 w-6 text-primary" />
              <CardTitle>Tips for Success</CardTitle>
            </div>
            <CardDescription>Expert advice to help you dominate the competition</CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              <li className="text-muted-foreground">
                Only focus on 1-2 fighters at a time, to max focus points and get good discipline cards.
              </li>
              <li className="text-muted-foreground">
                Keep an eye on the in-game economy; don't overspend credits or cash.
              </li>
              <li className="text-muted-foreground">
                Regularly rotate your fighters to avoid burnout and keep them progressing.
              </li>
              <li className="text-muted-foreground">
                Join online communities or forums to learn from other players and share strategies.
              </li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
