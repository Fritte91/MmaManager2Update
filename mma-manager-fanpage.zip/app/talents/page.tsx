import Image from "next/image"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

// Mock data for talents
const talentsData = {
  commonTalents: [
    {
      name: "Endurance",
      description: "Increases fighter's stamina recovery by 10%",
      image: "/placeholder.svg?height=100&width=100",
      color: "#4CAF50",
    },
    {
      name: "Quick Reflexes",
      description: "Improves dodge chance by 5%",
      image: "/placeholder.svg?height=100&width=100",
      color: "#2196F3",
    },
    {
      name: "Heavy Hands",
      description: "Increases punch damage by 8%",
      image: "/placeholder.svg?height=100&width=100",
      color: "#F44336",
    },
    {
      name: "Leg Day",
      description: "Increases kick damage by 8%",
      image: "/placeholder.svg?height=100&width=100",
      color: "#FF9800",
    },
    {
      name: "Clinch Expert",
      description: "Improves clinch control by 10%",
      image: "/placeholder.svg?height=100&width=100",
      color: "#9C27B0",
    },
    {
      name: "Takedown Defense",
      description: "Increases resistance to takedowns by 10%",
      image: "/placeholder.svg?height=100&width=100",
      color: "#607D8B",
    },
  ],
  rareTalents: [
    {
      name: "Counter Striker",
      description: "15% chance to counter attack after a successful dodge",
      image: "/placeholder.svg?height=100&width=100",
      color: "#1976D2",
    },
    {
      name: "Ground Specialist",
      description: "Increases ground control by 15%",
      image: "/placeholder.svg?height=100&width=100",
      color: "#388E3C",
    },
    {
      name: "Submission Expert",
      description: "Improves submission success rate by 12%",
      image: "/placeholder.svg?height=100&width=100",
      color: "#D32F2F",
    },
    {
      name: "Iron Chin",
      description: "Reduces damage taken from head strikes by 10%",
      image: "/placeholder.svg?height=100&width=100",
      color: "#FFA000",
    },
    {
      name: "Combo Master",
      description: "Increases combo damage by 15%",
      image: "/placeholder.svg?height=100&width=100",
      color: "#7B1FA2",
    },
  ],
  epicTalents: [
    {
      name: "One Punch KO",
      description: "5% chance to instantly KO opponent with a clean punch",
      image: "/placeholder.svg?height=100&width=100",
      color: "#C62828",
    },
    {
      name: "Submission Wizard",
      description: "Significantly improves submission success and reduces escape chance",
      image: "/placeholder.svg?height=100&width=100",
      color: "#283593",
    },
    {
      name: "Adrenaline Rush",
      description: "When health drops below 30%, gain 20% boost to all stats",
      image: "/placeholder.svg?height=100&width=100",
      color: "#00695C",
    },
    {
      name: "Perfect Timing",
      description: "Increases critical hit chance by 15%",
      image: "/placeholder.svg?height=100&width=100",
      color: "#FF5722",
    },
  ],
}

function TalentCard({ talent }) {
  return (
    <Card className="card-hover overflow-hidden border-t-4" style={{ borderTopColor: talent.color }}>
      <div className="p-4 flex items-center gap-4">
        <div className="relative w-16 h-16 flex-shrink-0">
          <Image src={talent.image || "/placeholder.svg"} alt={talent.name} fill className="object-cover rounded-md" />
        </div>
        <div>
          <h3 className="font-bold">{talent.name}</h3>
          <p className="text-sm text-muted-foreground">{talent.description}</p>
        </div>
      </div>
    </Card>
  )
}

function TalentSection({ title, talents }) {
  return (
    <section className="mb-12">
      <h2 className="text-2xl font-bold mb-6">{title}</h2>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {talents.map((talent, index) => (
          <TalentCard key={index} talent={talent} />
        ))}
      </div>
    </section>
  )
}

export default function TalentsPage() {
  return (
    <div className="container py-12 md:py-16 lg:py-24">
      <header className="text-center mb-12">
        <h1 className="text-4xl font-bold tracking-tight mb-4">Talents in MMA Manager 2</h1>
        <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
          Explore the various talents available to enhance your fighters' abilities
        </p>
      </header>

      <TalentSection title="Common Talents" talents={talentsData.commonTalents} />
      <TalentSection title="Rare Talents" talents={talentsData.rareTalents} />
      <TalentSection title="Epic Talents" talents={talentsData.epicTalents} />

      <Card className="mt-12">
        <CardHeader>
          <CardTitle>About Talents</CardTitle>
          <CardDescription>Understanding different talent cards is crucial</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <ul className="space-y-2 list-disc pl-5">
            <li>The fighter's Talents are available after completing Chapter 14 of the main story.</li>
            <li>
              Fighters unlock talents at levels 3 (common), 5 (rare), and 7 (epic). One talent per rarity can be
              equipped at a time.
            </li>
            <li>
              You receive 5 random talents the first time a fighter reaches each tier. Changing talents costs credits.
            </li>
            <li>Talents are passive effects that influence fights.</li>
            <li>
              Common talent points come from Fight Clubs. Rare ones from Tournaments. Epic talents can be unlocked with
              credits.
            </li>
            <li>Unlocking a new talent allows free switching of that tier for all fighters.</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  )
}
