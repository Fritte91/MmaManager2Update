import Image from "next/image"
import { Facebook, Twitter, Instagram, MessageCircle } from "lucide-react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

export default function Community() {
  return (
    <div className="container py-12 md:py-16 lg:py-24">
      <header className="text-center mb-12">
        <h1 className="text-4xl font-bold tracking-tight mb-4">Community Resources</h1>
        <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
          Join our community and follow us on social media for updates and discussions!
        </p>
      </header>

      <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
        <Card className="card-hover bg-blue-50 dark:bg-blue-950/30 border-blue-200 dark:border-blue-800">
          <CardHeader className="pb-2">
            <Facebook className="h-12 w-12 text-blue-600 mb-2" />
            <CardTitle>Facebook</CardTitle>
            <CardDescription>Join our Facebook group with over 10,000 members</CardDescription>
          </CardHeader>
          <CardContent className="pb-2">
            <p className="text-sm text-muted-foreground">
              Share your achievements, ask questions, and connect with other players.
            </p>
          </CardContent>
          <CardFooter>
            <Button asChild className="w-full bg-blue-600 hover:bg-blue-700">
              <a href="https://www.facebook.com/groups/935480524053924" target="_blank" rel="noopener noreferrer">
                Join Group
              </a>
            </Button>
          </CardFooter>
        </Card>

        <Card className="card-hover bg-indigo-50 dark:bg-indigo-950/30 border-indigo-200 dark:border-indigo-800">
          <CardHeader className="pb-2">
            <MessageCircle className="h-12 w-12 text-indigo-600 mb-2" />
            <CardTitle>Discord</CardTitle>
            <CardDescription>Join our active Discord server</CardDescription>
          </CardHeader>
          <CardContent className="pb-2">
            <p className="text-sm text-muted-foreground">
              Chat in real-time, find opponents, and get instant help from experienced players.
            </p>
          </CardContent>
          <CardFooter>
            <Button asChild className="w-full bg-indigo-600 hover:bg-indigo-700">
              <a href="https://discord.com" target="_blank" rel="noopener noreferrer">
                Join Server
              </a>
            </Button>
          </CardFooter>
        </Card>

        <Card className="card-hover bg-pink-50 dark:bg-pink-950/30 border-pink-200 dark:border-pink-800">
          <CardHeader className="pb-2">
            <Instagram className="h-12 w-12 text-pink-600 mb-2" />
            <CardTitle>Instagram</CardTitle>
            <CardDescription>Follow us on Instagram</CardDescription>
          </CardHeader>
          <CardContent className="pb-2">
            <p className="text-sm text-muted-foreground">
              Get the latest visual updates, fighter showcases, and event announcements.
            </p>
          </CardContent>
          <CardFooter>
            <Button asChild className="w-full bg-pink-600 hover:bg-pink-700">
              <a href="https://www.instagram.com/mma.manager2/" target="_blank" rel="noopener noreferrer">
                Follow
              </a>
            </Button>
          </CardFooter>
        </Card>

        <Card className="card-hover bg-sky-50 dark:bg-sky-950/30 border-sky-200 dark:border-sky-800">
          <CardHeader className="pb-2">
            <Twitter className="h-12 w-12 text-sky-600 mb-2" />
            <CardTitle>Twitter</CardTitle>
            <CardDescription>Follow us on Twitter</CardDescription>
          </CardHeader>
          <CardContent className="pb-2">
            <p className="text-sm text-muted-foreground">
              Stay updated with the latest news, updates, and community events.
            </p>
          </CardContent>
          <CardFooter>
            <Button asChild className="w-full bg-sky-600 hover:bg-sky-700">
              <a href="https://x.com/preystudiosmma" target="_blank" rel="noopener noreferrer">
                Follow
              </a>
            </Button>
          </CardFooter>
        </Card>
      </div>

      <div className="mt-16 text-center">
        <h2 className="text-3xl font-bold tracking-tight mb-8">Official Game Developer</h2>
        <div className="flex justify-center">
          <div className="relative w-64 h-64">
            <Image
              src="/placeholder.svg?height=256&width=256"
              alt="Prey Studios Logo"
              fill
              className="object-contain"
            />
          </div>
        </div>
        <div className="mt-8 max-w-2xl mx-auto">
          <p className="text-muted-foreground">
            MMA Manager 2 is developed by Prey Studios. This fanpage is created by the community to help players get the
            most out of their gaming experience.
          </p>
          <div className="mt-6">
            <Button asChild variant="outline">
              <a href="https://preystudios.com" target="_blank" rel="noopener noreferrer">
                Visit Official Website
              </a>
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
