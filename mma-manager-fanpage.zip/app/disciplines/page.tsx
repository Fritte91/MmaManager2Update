import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

// Mock data for disciplines
const disciplinesData = {
  common: [
    { name: "Boxing", image: "/placeholder.svg?height=100&width=100", stars: 3, bonus: "Punch Power +10%" },
    { name: "Kickboxing", image: "/placeholder.svg?height=100&width=100", stars: 3, bonus: "Kick Power +10%" },
    { name: "Wrestling", image: "/placeholder.svg?height=100&width=100", stars: 3, bonus: "Takedown +10%" },
    { name: "Jiu-Jitsu", image: "/placeholder.svg?height=100&width=100", stars: 3, bonus: "Submission +10%" },
    { name: "Muay Thai", image: "/placeholder.svg?height=100&width=100", stars: 3, bonus: "Clinch +10%" },
  ],
  epic: [
    { name: "Karate", image: "/placeholder.svg?height=100&width=100", stars: 4, bonus: "Counter Strike +15%" },
    { name: "Taekwondo", image: "/placeholder.svg?height=100&width=100", stars: 4, bonus: "High Kick +15%" },
    { name: "Sambo", image: "/placeholder.svg?height=100&width=100", stars: 4, bonus: "Ground Control +15%" },
    { name: "Judo", image: "/placeholder.svg?height=100&width=100", stars: 4, bonus: "Throw Power +15%" },
    { name: "Krav Maga", image: "/placeholder.svg?height=100&width=100", stars: 4, bonus: "Strike Defense +15%" },
  ],
  legendary: [
    { name: "MMA", image: "/placeholder.svg?height=100&width=100", stars: 5, bonus: "All Stats +5%" },
    { name: "Capoeira", image: "/placeholder.svg?height=100&width=100", stars: 5, bonus: "Unpredictability +20%" },
    { name: "Lethwei", image: "/placeholder.svg?height=100&width=100", stars: 5, bonus: "Headbutt Damage +25%" },
    { name: "Pankration", image: "/placeholder.svg?height=100&width=100", stars: 5, bonus: "Ground & Pound +20%" },
  ],
}

function DisciplineCard({ name, image, stars, bonus }) {
  return (
    <Card className="card-hover text-center">
      <CardContent className="p-6">
        <div className="relative w-20 h-20 mx-auto mb-4">
          <Image src={image || "/placeholder.svg"} alt={name} fill className="object-contain" />
        </div>
        <h3 className="font-bold mb-1">{name}</h3>
        <p className="text-sm text-muted-foreground mb-2">{bonus}</p>
        <div className="text-yellow-400">
          {"★".repeat(stars)}
          {"☆".repeat(5 - stars)}
        </div>
      </CardContent>
    </Card>
  )
}

function DisciplineSection({ title, data }) {
  return (
    <section className="mb-12">
      <h2 className="text-2xl font-bold mb-6">{title}</h2>
      <div className="grid gap-4 grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
        {data.map((item, idx) => (
          <DisciplineCard key={idx} {...item} />
        ))}
      </div>
    </section>
  )
}

export default function DisciplinesPage() {
  return (
    <div className="container py-12 md:py-16 lg:py-24">
      <header className="text-center mb-12">
        <h1 className="text-4xl font-bold tracking-tight mb-4">Fighter Disciplines</h1>
        <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
          Browse the different disciplines available in MMA Manager 2
        </p>
      </header>

      <DisciplineSection title="Common Disciplines" data={disciplinesData.common} />
      <DisciplineSection title="Epic Disciplines" data={disciplinesData.epic} />
      <DisciplineSection title="Legendary Disciplines" data={disciplinesData.legendary} />

      <div className="mt-16">
        <h2 className="text-3xl font-bold tracking-tight mb-8 text-center">Disciplines Information</h2>
        <Card>
          <CardContent className="p-6">
            <Accordion type="single" collapsible className="w-full">
              <AccordionItem value="unlocking">
                <AccordionTrigger>Unlocking</AccordionTrigger>
                <AccordionContent>
                  <ul className="space-y-2 list-disc pl-5">
                    <li>Disciplines are available after completing chapter 7 of the main story.</li>
                    <li>
                      Disciplines are cards representing martial arts that, when equipped to a fighter, grant them bonus
                      effects and fighting statistics.
                    </li>
                    <li>
                      Each fighter will individually unlock the ability to equip a discipline when reaching fighter
                      level 4. The fighters unlock the ability to equip a second discipline when reaching fighter level
                      8.
                    </li>
                  </ul>
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="drawing">
                <AccordionTrigger>Drawing</AccordionTrigger>
                <AccordionContent>
                  <ul className="space-y-2 list-disc pl-5">
                    <li>
                      Discipline cards are obtained at random by using knowledge scrolls. When drawing a discipline
                      card, it can be of rarity: common, epic, or legendary.
                    </li>
                    <li>
                      Knowledge scrolls can be bought for Credits or obtained through Daily Tasks, Fight Club rewards,
                      Tournament rewards.
                    </li>
                    <li>
                      After using 100 knowledge scrolls, you earn a legendary knowledge scroll. When using it, you are
                      guaranteed to draw a legendary card.
                    </li>
                    <li>
                      All cards drawn can be browsed in the collection, where you can recycle, upgrade, or equip them.
                    </li>
                    <li>Epic and legendary cards can also be bought from the discipline store.</li>
                  </ul>
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="recycling">
                <AccordionTrigger>Recycling</AccordionTrigger>
                <AccordionContent>
                  <ul className="space-y-2 list-disc pl-5">
                    <li>
                      Discipline cards can be recycled, deleting them but granting discipline points based on the card
                      star level.
                    </li>
                    <li>Recycling a legendary card grants reroll tokens.</li>
                    <li>Discipline points are used to upgrade cards of the same rarity.</li>
                  </ul>
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="upgrade">
                <AccordionTrigger>Upgrade</AccordionTrigger>
                <AccordionContent>
                  <ul className="space-y-2 list-disc pl-5">
                    <li>Upgrading discipline cards is vital for your fighter's success.</li>
                    <li>Common, Epic, and Legendary cards can be upgraded to levels 3, 4, and 5, respectively.</li>
                    <li>Each upgrade gives the card a new random statistic.</li>
                    <li>Rerolling a card at max level lets you choose one stat to replace with a new random one.</li>
                    <li>Common and Epic rerolls cost credits; Legendary rerolls cost reroll tokens.</li>
                    <li>Legendary cards can be boosted by increasing one stat at max level, using boost tokens.</li>
                  </ul>
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="equipping">
                <AccordionTrigger>Equipping</AccordionTrigger>
                <AccordionContent>
                  <ul className="space-y-2 list-disc pl-5">
                    <li>
                      Each discipline card can be equipped to a single fighter. The effect and statistics will take
                      effect in all fights.
                    </li>
                    <li>Discipline cards below level 3 do not provide their discipline effect, only the stats.</li>
                    <li>A fighter cannot have two cards of the same discipline equipped.</li>
                  </ul>
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="maxStats">
                <AccordionTrigger>Max Attribute Stats</AccordionTrigger>
                <AccordionContent>
                  <ul className="space-y-2">
                    <li>
                      <span className="font-semibold">Agility</span> MAX = <span className="text-primary">14%</span>
                    </li>
                    <li>
                      <span className="font-semibold">Condition</span> MAX = <span className="text-primary">14%</span>
                    </li>
                    <li>
                      <span className="font-semibold">Strength</span> MAX = <span className="text-primary">14%</span>
                    </li>
                    <li>
                      <span className="font-semibold">Intelligence</span> MAX ={" "}
                      <span className="text-primary">14%</span>
                    </li>
                    <li>
                      <span className="font-semibold">Health</span> MAX = <span className="text-primary">25%</span>
                    </li>
                    <li>
                      <span className="font-semibold">Takedown Skill</span> MAX ={" "}
                      <span className="text-primary">10%</span>
                    </li>
                  </ul>
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="attributeBoost">
                <AccordionTrigger>Attribute Boost</AccordionTrigger>
                <AccordionContent>
                  <ul className="space-y-2">
                    <li>
                      <span className="font-semibold">Agility</span> Boost ={" "}
                      <span className="text-primary">0.4% MAX</span>
                    </li>
                    <li>
                      <span className="font-semibold">Condition</span> Boost ={" "}
                      <span className="text-primary">0.4% MAX</span>
                    </li>
                    <li>
                      <span className="font-semibold">Strength</span> Boost ={" "}
                      <span className="text-primary">0.4% MAX</span>
                    </li>
                    <li>
                      <span className="font-semibold">Health</span> Boost = <span className="text-primary">1% MAX</span>
                    </li>
                    <li>
                      <span className="font-semibold">Takedown Skill</span> Boost ={" "}
                      <span className="text-primary">0.3% MAX</span>
                    </li>
                  </ul>
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
