export const DisciplinesData = {
  common: [
    { name: "Boxing", image: "/placeholder.svg?height=100&width=100", stars: 3, bonus: "Punch Power +10%" },
    { name: "Kickboxing", image: "/placeholder.svg?height=100&width=100", stars: 3, bonus: "Kick Power +10%" },
    { name: "Wrestling", image: "/placeholder.svg?height=100&width=100", stars: 3, bonus: "Takedown +10%" },
    { name: "Jiu-Jitsu", image: "/placeholder.svg?height=100&width=100", stars: 3, bonus: "Submission +10%" },
    { name: "Muay Thai", image: "/placeholder.svg?height=100&width=100", stars: 3, bonus: "Clinch +10%" },
  ],
  epic: [
    { name: "Karate", image: "/placeholder.svg?height=100&width=100", stars: 4, bonus: "Counter Strike +15%" },
    { name: "Taekwondo", image: "/placeholder.svg?height=100&width=100", stars: 4, bonus: "High Kick +15%" },
    { name: "Sambo", image: "/placeholder.svg?height=100&width=100", stars: 4, bonus: "Ground Control +15%" },
    { name: "Judo", image: "/placeholder.svg?height=100&width=100", stars: 4, bonus: "Throw Power +15%" },
    { name: "Krav Maga", image: "/placeholder.svg?height=100&width=100", stars: 4, bonus: "Strike Defense +15%" },
  ],
  legendary: [
    { name: "MMA", image: "/placeholder.svg?height=100&width=100", stars: 5, bonus: "All Stats +5%" },
    { name: "Capoeira", image: "/placeholder.svg?height=100&width=100", stars: 5, bonus: "Unpredictability +20%" },
    { name: "Lethwei", image: "/placeholder.svg?height=100&width=100", stars: 5, bonus: "Headbutt Damage +25%" },
    { name: "Pankration", image: "/placeholder.svg?height=100&width=100", stars: 5, bonus: "Ground & Pound +20%" },
  ],
}
