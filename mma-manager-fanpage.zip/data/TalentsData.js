export const TalentsData = {
  commonTalents: [
    {
      name: "Endurance",
      description: "Increases fighter's stamina recovery by 10%",
      image: "/placeholder.svg?height=100&width=100",
      color: "#4CAF50",
    },
    {
      name: "Quick Reflexes",
      description: "Improves dodge chance by 5%",
      image: "/placeholder.svg?height=100&width=100",
      color: "#2196F3",
    },
    {
      name: "Heavy Hands",
      description: "Increases punch damage by 8%",
      image: "/placeholder.svg?height=100&width=100",
      color: "#F44336",
    },
    {
      name: "Leg Day",
      description: "Increases kick damage by 8%",
      image: "/placeholder.svg?height=100&width=100",
      color: "#FF9800",
    },
    {
      name: "Clinch Expert",
      description: "Improves clinch control by 10%",
      image: "/placeholder.svg?height=100&width=100",
      color: "#9C27B0",
    },
    {
      name: "Takedown Defense",
      description: "Increases resistance to takedowns by 10%",
      image: "/placeholder.svg?height=100&width=100",
      color: "#607D8B",
    },
  ],
  rareTalents: [
    {
      name: "Counter Striker",
      description: "15% chance to counter attack after a successful dodge",
      image: "/placeholder.svg?height=100&width=100",
      color: "#1976D2",
    },
    {
      name: "Ground Specialist",
      description: "Increases ground control by 15%",
      image: "/placeholder.svg?height=100&width=100",
      color: "#388E3C",
    },
    {
      name: "Submission Expert",
      description: "Improves submission success rate by 12%",
      image: "/placeholder.svg?height=100&width=100",
      color: "#D32F2F",
    },
    {
      name: "Iron Chin",
      description: "Reduces damage taken from head strikes by 10%",
      image: "/placeholder.svg?height=100&width=100",
      color: "#FFA000",
    },
    {
      name: "Combo Master",
      description: "Increases combo damage by 15%",
      image: "/placeholder.svg?height=100&width=100",
      color: "#7B1FA2",
    },
  ],
  epicTalents: [
    {
      name: "One Punch KO",
      description: "5% chance to instantly KO opponent with a clean punch",
      image: "/placeholder.svg?height=100&width=100",
      color: "#C62828",
    },
    {
      name: "Submission Wizard",
      description: "Significantly improves submission success and reduces escape chance",
      image: "/placeholder.svg?height=100&width=100",
      color: "#283593",
    },
    {
      name: "Adrenaline Rush",
      description: "When health drops below 30%, gain 20% boost to all stats",
      image: "/placeholder.svg?height=100&width=100",
      color: "#00695C",
    },
    {
      name: "Perfect Timing",
      description: "Increases critical hit chance by 15%",
      image: "/placeholder.svg?height=100&width=100",
      color: "#FF5722",
    },
  ],
}
